//
//  ViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/16/21.
//

import UIKit
class HomeViewController: UIViewController {
    override func viewDidLoad() {
    super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
