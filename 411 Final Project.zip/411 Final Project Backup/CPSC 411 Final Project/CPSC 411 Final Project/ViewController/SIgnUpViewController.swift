//
//  ViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/16/21.
//
import UIKit
import FirebaseAuth
import FirebaseFirestore
import GoogleSignIn

class SIgnUpViewController: UIViewController {
    @IBOutlet weak var FirstNameTextField: UITextField!
    @IBOutlet weak var LastNameTextField: UITextField!
    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var SignUpButton: UIButton!
    @IBOutlet weak var ErrorLabel: UILabel!
    @IBOutlet var SignUpGoogle: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        Init()
    }
    func Init(){
        ErrorLabel.alpha = 0
        Utilities.styleTextField(FirstNameTextField)
        Utilities.styleTextField(LastNameTextField)
        Utilities.styleTextField(EmailTextField)
        Utilities.styleTextField(PasswordTextField)
        Utilities.styleFilledButton(SignUpButton)
    }
    var googleSignIn = GIDSignIn.sharedInstance
    @IBAction func GoogleSignUpTapped(_ sender: Any) {
            let googleConfig = GIDConfiguration(clientID: "913952454514-ofe59hqc0anmfutsgsrt2dfdr8tcd6n6.apps.googleusercontent.com")
            self.googleSignIn.signIn(with: googleConfig, presenting: self) { user, error in
                if error == nil {
                    guard let user = user else {
                        print("User Cancelled the Sign in ")
                        return
                    }
                    let userFirstName = user.profile?.givenName ?? ""
                    let userLastName = user.profile?.familyName ?? ""
                    let userEmail = user.profile?.email ?? ""
                    print("Google User First Name: \(userFirstName)")
                    print("Google User Last Name: \(userLastName)")
                    print("Google User Email: \(userEmail)")
                    
                    let db =  Firestore.firestore()
                            
                    db.collection("GoogleUsers").addDocument(data: ["FirstName":userFirstName, "LastName":userLastName, "Email": userEmail]) {(error) in
                                
                            }
                        }
                    }
                    //Transition to the home screen
                    transitionToHome()
    }
    @IBAction func SignUpTapped(_ sender: Any) {
        //Validate the fields
        let error = validateFields()
        if error != nil{
            showError(message:error!)
        }
        else{
            //Create cleaned versions of the data
            let FirstName = FirstNameTextField.text!.trimmingCharacters(in: .whitespaces)
            let LastName = LastNameTextField.text!.trimmingCharacters(in: .whitespaces)
            let email = EmailTextField.text!.trimmingCharacters(in: .whitespaces)
            let password = PasswordTextField.text!.trimmingCharacters(in: .whitespaces)
            //Create the user
            Auth.auth().createUser(withEmail: email, password: password){ (result, error) in
                if error != nil{
                    
                    //There was an error
                    self.showError(message:"Error creating user")
                }
                else{
                    //User was created, store first and last name
                    let db =  Firestore.firestore()
                    
                    db.collection("users").addDocument(data: ["firstname":FirstName, "lastname":LastName, "email": email]) {(error) in
                        if error != nil {
                        //Show Error Message
                            self.showError(message:"Error saving user data")
                        }
                    }
                }
            }
            //Transition to the home screen
            transitionToCaptcha()
        }
    }
    func showError(message:String){
        ErrorLabel.text = message
        ErrorLabel.alpha = 1
    }
    //Check the fields and validate that the data is correct. If everything is correct, this method returns nil. Otherwise returns  the error message.
    func validateFields() -> String?{
        //Check that all fields are filled in
    if FirstNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
    LastNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
    EmailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
    PasswordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == ""{
        return "Please fill in all fields."
    }
        let cleanedPassword = PasswordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if Utilities.isPasswordValid(cleanedPassword){
            return "Please make sure your password is at least 8 characters, contains a special character and a number."
        }
    return nil
}
    func transitionToHome(){
     let HomeViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.HomeViewController) as? HomeViewController
        
        view.window?.rootViewController = HomeViewController
        view.window?.makeKeyAndVisible()
    }
    func transitionToCaptcha(){
     let CaptchaViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.CaptchaViewController) as? CaptchaViewController
        
        view.window?.rootViewController = CaptchaViewController
        view.window?.makeKeyAndVisible()
    }
}
