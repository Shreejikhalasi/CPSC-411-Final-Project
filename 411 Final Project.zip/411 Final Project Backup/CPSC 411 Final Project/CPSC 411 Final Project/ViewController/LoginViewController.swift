//
//  ViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/16/21.
//
import UIKit
import FirebaseAuth
import GoogleSignIn

class LoginViewController: UIViewController {
    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var ErrorLabel: UILabel!
    @IBOutlet weak var LoginButton: UIButton!
    @IBOutlet var FancyButton: GIDSignInButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        Init()
        // Do any additional setup after loading the view.
    }
    func Init(){
        ErrorLabel.alpha = 0
        Utilities.styleTextField(EmailTextField)
        Utilities.styleTextField(PasswordTextField)
        Utilities.styleFilledButton(LoginButton)
    }
    var googleSignIn = GIDSignIn.sharedInstance
    @IBAction func FancyGoogleSignInTapped(_ sender: Any) {
        self.googleAuthLogin()
    }
    func googleAuthLogin(){
        let googleConfig = GIDConfiguration(clientID: "913952454514-ofe59hqc0anmfutsgsrt2dfdr8tcd6n6.apps.googleusercontent.com")
        self.googleSignIn.signIn(with: googleConfig, presenting: self) { user, error in
            if error == nil {
                guard let user = user else {
                    print("User Cancelled the Sign in ")
                    return
                }
                let userFirstName = user.profile?.givenName ?? ""
                let userLastName = user.profile?.familyName ?? ""
                let userEmail = user.profile?.email ?? ""
                print("Google User First Name: \(userFirstName)")
                print("Google User Last Name: \(userLastName)")
                print("Google User Email: \(userEmail)")
                let HomeViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.HomeViewController) as? HomeViewController
                self.view.window?.rootViewController = HomeViewController
                self.view.window?.makeKeyAndVisible()
            }
        }
    }
    @IBAction func LoginTapped(_ sender: Any) {
        // Validate Text Fields
        let email = EmailTextField.text?.trimmingCharacters(in:.whitespacesAndNewlines)
        let password = PasswordTextField.text?.trimmingCharacters(in:.whitespacesAndNewlines)
        Auth.auth().signIn(withEmail: email!, password: password!) {(result, error) in
            if error != nil {
                //couldn't sign in
                self.ErrorLabel.text = error!.localizedDescription
                self.ErrorLabel.alpha = 1
            }
            else {
                let CaptchaViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.CaptchaViewController) as? CaptchaViewController
                self.view.window?.rootViewController = CaptchaViewController
                self.view.window?.makeKeyAndVisible()
            }
        }
    }

}
