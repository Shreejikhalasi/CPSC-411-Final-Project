//
//  CaptureViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/29/21.
//

import UIKit
class CaptchaViewController: UIViewController {
    var alphas : [String] = []
    var captchaString = ""
    var i1 : Int = 0
    var i2 : Int = 0
    var i3 : Int = 0
    var i4 : Int = 0
    var i5 : Int = 0
    let seconds = 2.0
    @IBOutlet weak var CaptchaLabel: UILabel!
    @IBOutlet weak var CaptchaTextField: UITextField!
    @IBOutlet weak var StatusLabel: UILabel!
    @IBOutlet weak var SubmitButton: UIButton!
    @IBOutlet weak var ReloadButton: UIButton!
        override func viewDidLoad() {
        super.viewDidLoad()
        StatusLabel.alpha = 0.0
        Utilities.styleFilledButton(SubmitButton)
        Utilities.styleFilledButton(ReloadButton)
        // Do any additional setup after loading the view.
        alphas = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s","t", "u", "v", "w", "x", "y", "z","A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                          "K", "L", "M", "N", "O", "P", "Q", "R", "S","T", "U", "V", "W", "X", "Y", "Z"]
    }
    override func viewWillAppear(_ animated: Bool) {
        reloadCaptcha()
    }
        func reloadCaptcha(){
        i1 = Int(arc4random()) % alphas.count
        i2 = Int(arc4random()) % alphas.count
        i3 = Int(arc4random()) % alphas.count
        i4 = Int(arc4random()) % alphas.count
        i5 = Int(arc4random()) % alphas.count
        captchaString = "\(alphas[i1])\(alphas[i2])\(alphas[i3])\(alphas[i4])\(alphas[i5])"
        CaptchaLabel.text = captchaString
    }
    @IBAction func ReloadButton(_ sender: UIButton) {
        reloadCaptcha()
        StatusLabel.alpha = 0.0
    }
    @IBAction func SubmitButton(_ sender: UIButton) {
        if CaptchaLabel.text == CaptchaTextField.text{
            StatusLabel.alpha = 1
            StatusLabel.text = "Success"
            StatusLabel.textColor = .green
        } else {
            StatusLabel.alpha = 1
            StatusLabel.text = "Failed"
            StatusLabel.textColor = .red
        }
        if CaptchaLabel.text == CaptchaTextField.text{
            perform(#selector(transitionToHome), with: nil, afterDelay: seconds)
        }
    }
    @objc func transitionToHome(){
     let HomeViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.HomeViewController) as? HomeViewController
        view.window?.rootViewController = HomeViewController
        view.window?.makeKeyAndVisible()
    }
}
