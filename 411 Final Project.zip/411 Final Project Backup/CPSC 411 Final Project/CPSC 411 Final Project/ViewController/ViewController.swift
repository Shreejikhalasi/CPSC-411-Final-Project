//
//  ViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/16/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LoginButton: UIButton!
    @IBOutlet weak var SignUpButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        Init()
        // Do any additional setup after loading the view.
    }

    func Init(){
        Utilities.styleHollowButton(SignUpButton)
        Utilities.styleFilledButton(LoginButton)
        
    }

}

