//
//  ViewController.swift
//  CPSC 411 Final Project
//
//  Created by Shreeji Khalasi on 11/16/21.
//

import Foundation
struct Constants {
    struct Storyboard {
        static let HomeViewController = "HomeVC"
        static let CaptchaViewController = "CaptchVC"
    }
}
